<?php
//set some options
$show_logical_header=true;
$show_internal_element_text_outside=true; // show list text outiside select box (for sorting)


$first_week_sept10=37; //for LISTWEEKSSCH
$last_week_of_year=53; //for LISTWEEKSSCH


//load main file
require ('order_lesson.php');

?>
